function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ceUXf20oZH":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

